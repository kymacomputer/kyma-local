---
updatedAt: 2026-05-27T18:08:33.000Z
agentTools:
  projectIndex: https://developer.ironcladapp.com/llms.txt
---

# List All Records

View all records in the company, with filtering available via query parameters. 

**OAuth Scope required:** `public.records.readRecords`

# OpenAPI definition

```json
{
  "openapi": "3.1.0",
  "info": {
    "title": "Ironclad Public API",
    "description": "Documentation for Ironclad's REST API.\n\n## Pagination\n\nList endpoints (for example `/obligations`, `/records`, `/entities`, and `/workflows`) return results one page at a time. Request pages with the `page` (zero-based) and `pageSize` query parameters; see the `pageSize` parameter on each endpoint for its default and maximum. Each response echoes `page` and `pageSize` and includes `count` (the total number of items matching the query across ALL pages) and `list` (the items on the current page). When `count` is greater than the number of items you have retrieved so far, request the next page by incrementing `page` until you have collected everything you need.",
    "contact": {
      "name": "Ironclad Support",
      "email": "support@ironcladapp.com"
    },
    "version": "1"
  },
  "servers": [
    {
      "url": "https://ironcladapp.com/public/api/v1",
      "description": "Production server"
    },
    {
      "url": "https://eu1.ironcladapp.com/public/api/v1",
      "description": "EU Production server"
    },
    {
      "url": "https://demo.ironcladapp.com/public/api/v1",
      "description": "Demo server"
    }
  ],
  "paths": {
    "/records": {
      "get": {
        "summary": "List All Records",
        "description": "View all records in the company, with filtering available via query parameters. \n\n**OAuth Scope required:** `public.records.readRecords`",
        "operationId": "list-all-records",
        "parameters": [
          {
            "$ref": "#/components/parameters/XAsUserEmail"
          },
          {
            "$ref": "#/components/parameters/XAsUserId"
          },
          {
            "$ref": "#/components/parameters/QueryPageNumber"
          },
          {
            "$ref": "#/components/parameters/QueryPageSize"
          },
          {
            "$ref": "#/components/parameters/HydrateEntitiesFlag"
          },
          {
            "$ref": "#/components/parameters/RecordType"
          },
          {
            "$ref": "#/components/parameters/RecordLastUpdated"
          },
          {
            "$ref": "#/components/parameters/RecordFilter"
          },
          {
            "$ref": "#/components/parameters/RecordSearch"
          },
          {
            "name": "sortField",
            "in": "query",
            "description": "The field to sort Records. Only one field is supported in the sort operation.",
            "schema": {
              "type": "string",
              "enum": [
                "agreementDate",
                "name",
                "lastUpdated"
              ],
              "default": "agreementDate"
            }
          },
          {
            "name": "sortDirection",
            "in": "query",
            "description": "The direction the records are sorted by in correlation with the `sortField`.",
            "schema": {
              "type": "string",
              "enum": [
                "ASC",
                "DESC"
              ],
              "default": "DESC"
            }
          },
          {
            "$ref": "#/components/parameters/addressAsObject"
          }
        ],
        "security": [
          {
            "sec0": [],
            "OAuth2": [
              "public.records.readRecords"
            ]
          }
        ],
        "responses": {
          "200": {
            "description": "200",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {
                    "page": {
                      "type": "integer",
                      "example": 0,
                      "default": 0
                    },
                    "pageSize": {
                      "type": "integer",
                      "example": 20,
                      "default": 0
                    },
                    "count": {
                      "type": "integer",
                      "example": 1234,
                      "default": 0
                    },
                    "list": {
                      "type": "array",
                      "items": {
                        "$ref": "#/components/schemas/RecordModel"
                      }
                    }
                  }
                }
              }
            }
          },
          "400": {
            "description": "400",
            "content": {
              "application/json": {
                "schema": {
                  "type": "object",
                  "properties": {}
                }
              }
            }
          }
        },
        "tags": [
          "Records"
        ]
      }
    }
  },
  "components": {
    "schemas": {
      "RecordModel": {
        "type": "object",
        "required": [
          "id",
          "ironcladId",
          "type",
          "name",
          "lastUpdated",
          "properties",
          "attachments",
          "links"
        ],
        "properties": {
          "id": {
            "type": "string",
            "description": "The unique identifier of the record",
            "example": "22e2ff72-56a1-4711-a4ca-41328d311e9f"
          },
          "ironcladId": {
            "type": "string",
            "description": "The unique Ironclad identifier of the record",
            "example": "IC-1"
          },
          "type": {
            "type": "string",
            "description": "The record type id. The same id is returned as `recordType` by the Workflows API, so records and workflows can be matched on record type.",
            "example": "consultingAgreement"
          },
          "typeDisplayName": {
            "type": "string",
            "description": "The human-readable label for the record type (`type`), for example \"Consulting Agreement\". Omitted when the record type has no display label; it is never returned as an empty string.",
            "example": "Consulting Agreement"
          },
          "name": {
            "type": "string",
            "description": "The name of the record",
            "example": "Consulting Agreement with Jane Doe"
          },
          "lastUpdated": {
            "type": "string",
            "description": "The date (ISO8601 format) the record was last updated",
            "format": "date-time",
            "example": "2018-05-08T17:28:10Z"
          },
          "properties": {
            "$ref": "#/components/schemas/RecordProperties"
          },
          "attachments": {
            "type": "object",
            "description": "The attachments associated with the record keyed by the attachment key",
            "additionalProperties": {
              "type": "object",
              "required": [
                "filename",
                "href"
              ],
              "properties": {
                "filename": {
                  "type": "string",
                  "description": "The name of the attachment",
                  "example": "2018-05-08 - Doe, Jane - Consulting Agreement.pdf"
                },
                "contentType": {
                  "type": "string",
                  "description": "The content type of the attachment",
                  "example": "application/json"
                },
                "href": {
                  "type": "string",
                  "description": "The URL to download the attachment via the public API",
                  "example": "https://ironcladapp.com/public/api/v1/records/22e2ff72-56a1-4711-a4ca-41328d311e9f/attachments/signedCopy"
                },
                "fileHash": {
                  "type": "string",
                  "description": "The SHA-256 hash of the attachment's contents, as a hex string. Use this to detect whether an attachment changed without downloading it.",
                  "example": "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08"
                },
                "hashAlgorithm": {
                  "type": "string",
                  "enum": [
                    "sha256"
                  ],
                  "description": "The algorithm used to compute `fileHash`.",
                  "example": "sha256"
                }
              }
            }
          },
          "links": {
            "type": "array",
            "description": "The unique identifiers for the linked records",
            "items": {
              "type": "object",
              "required": [
                "recordId"
              ],
              "properties": {
                "recordId": {
                  "type": "string",
                  "description": "The unique identifier of the linked record",
                  "example": "df1c2805-f5a3-4a14-9386-c28d950dff49"
                }
              }
            }
          },
          "parentId": {
            "type": "string",
            "description": "The unique identifier of the parent record",
            "example": "d10b8c01-5c54-4a59-82cb-51e3825182e9"
          },
          "parentLinkType": {
            "$ref": "#/components/schemas/LinkType"
          },
          "childIds": {
            "type": "array",
            "description": "The unique identifiers of the child records",
            "items": {
              "type": "string",
              "example": "4a785686-d3d5-47bc-960e-3df0df871ea9"
            }
          },
          "contractStatus": {
            "type": "object",
            "description": "A record or contract status indicates whether a contract is active or inactive in addition to a sub-status calculated based on the contract's lifecycle data such as the effective date, expiration date, and auto-renewal type etc. For a detailed description of contract statuses reference this [article](https://support.ironcladapp.com/hc/en-us/articles/17438784927127-Contract-and-Record-Status-Overview).",
            "required": [
              "status",
              "enhancedStatus"
            ],
            "properties": {
              "status": {
                "type": "string",
                "description": "Base status of a contract.",
                "example": "active",
                "enum": [
                  "active",
                  "inactive",
                  "indeterminate"
                ]
              },
              "enhancedStatus": {
                "type": "string",
                "description": "A detailed sub-status of a contract calculated based on the lifecycle properties.",
                "example": "auto-renewing",
                "enum": [
                  "evergreen",
                  "auto-renewing",
                  "expiring",
                  "terminating",
                  "superseding",
                  "extending",
                  "active",
                  "inactive",
                  "unknown",
                  "activating",
                  "executed"
                ]
              },
              "remainingDuration": {
                "type": "string",
                "description": "Duration remaining for the current status.",
                "example": "P26D"
              },
              "eventDate": {
                "type": "string",
                "description": "Date when the current contract status went into effect.",
                "example": "2024-07-02T00:00:00.000Z"
              },
              "message": {
                "type": "string",
                "description": "Human readable message regarding the contract status.",
                "example": "Auto-renewing on Jul 2, 2024"
              }
            }
          },
          "source": {
            "description": "The origin of how the record was created",
            "oneOf": [
              {
                "$ref": "#/components/schemas/SourcedFromWorkflow"
              },
              {
                "$ref": "#/components/schemas/SourcedFromImportProject"
              },
              {
                "$ref": "#/components/schemas/SourcedFromSingleImport"
              },
              {
                "$ref": "#/components/schemas/SourcedFromClickwrap"
              },
              {
                "$ref": "#/components/schemas/SourcedFromConnector"
              },
              {
                "$ref": "#/components/schemas/SourcedFromIntegration"
              },
              {
                "$ref": "#/components/schemas/SourcedFromContract"
              },
              {
                "$ref": "#/components/schemas/SourcedFromMetadataImport"
              },
              {
                "$ref": "#/components/schemas/SourcedFromAiChat"
              },
              {
                "$ref": "#/components/schemas/SourcedFromAiExtraction"
              }
            ]
          },
          "amendments": {
            "type": "array",
            "description": "The unique identifiers of amendment records that amend this record",
            "items": {
              "type": "string",
              "example": "IC-124"
            }
          }
        }
      },
      "RecordProperties": {
        "type": "object",
        "description": "The record properties associated with the record",
        "additionalProperties": {
          "$ref": "#/components/schemas/RecordPropertyType"
        }
      },
      "RecordPropertyType": {
        "type": "object",
        "oneOf": [
          {
            "$ref": "#/components/schemas/RecordPropertyString"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyNumber"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyBoolean"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyDate"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyDuration"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyEmail"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyMonetaryAmount"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyClause"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyPlaybookClause"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyAddress"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyArray"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyReference"
          }
        ]
      },
      "EntityProperties": {
        "type": "object",
        "description": "The entity properties associated with the entity",
        "additionalProperties": {
          "$ref": "#/components/schemas/EntityPropertyType"
        }
      },
      "EntityPropertyType": {
        "type": "object",
        "oneOf": [
          {
            "$ref": "#/components/schemas/RecordPropertyString"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyNumber"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyBoolean"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyDate"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyDuration"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyEmail"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyMonetaryAmount"
          },
          {
            "$ref": "#/components/schemas/RecordPropertyAddress"
          }
        ]
      },
      "RecordPropertyArray": {
        "title": "Record Property Array",
        "type": "object",
        "description": "An array-type record property",
        "required": [
          "type",
          "value"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The data type of the property",
            "enum": [
              "array"
            ],
            "example": "array"
          },
          "value": {
            "type": "array",
            "items": {
              "oneOf": [
                {
                  "type": "string"
                },
                {
                  "type": "object",
                  "description": "A resolved entity reference element of a multi-entity entity_references array",
                  "required": [
                    "recordId"
                  ],
                  "properties": {
                    "recordId": {
                      "type": "string",
                      "example": "REC12345"
                    },
                    "subTypeId": {
                      "type": "string",
                      "example": "contract"
                    },
                    "namedTypeIds": {
                      "type": "array",
                      "items": {
                        "type": "string"
                      }
                    },
                    "readableId": {
                      "type": "string",
                      "example": "ENTITY-1"
                    },
                    "attributes": {
                      "type": "object",
                      "additionalProperties": true
                    }
                  }
                }
              ]
            },
            "minItems": 1,
            "example": [
              "red",
              "blue"
            ]
          }
        }
      },
      "EntityReferenceValue": {
        "type": "object",
        "description": "A reference to an entity record, optionally enriched with the entity's readable id, relationship types, and attributes. Resolved elements of a multi-entity entity_references array mirror this shape.",
        "required": [
          "recordId"
        ],
        "properties": {
          "recordId": {
            "type": "string",
            "description": "The unique identifier of the referenced record",
            "example": "REC12345"
          },
          "subTypeId": {
            "type": "string",
            "description": "Optional sub-type identifier for the referenced record",
            "example": "contract"
          },
          "namedTypeIds": {
            "type": "array",
            "description": "The unique identifiers of the relationship types associated with the entity",
            "items": {
              "type": "string",
              "example": "43d3e321-e89b-12d3-a456-426614174000"
            }
          },
          "readableId": {
            "type": "string",
            "description": "The unique identifier of the referenced record",
            "example": "ENTITY-1"
          },
          "attributes": {
            "$ref": "#/components/schemas/EntityProperties"
          }
        }
      },
      "RecordPropertyReference": {
        "type": "object",
        "description": "A reference-type record property that points to another record",
        "required": [
          "type",
          "value"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The data type of the property",
            "enum": [
              "reference"
            ],
            "example": "reference"
          },
          "value": {
            "$ref": "#/components/schemas/EntityReferenceValue"
          },
          "originalValue": {
            "type": "object",
            "description": "The original reference value before amendment (only present when property is amended)",
            "required": [
              "recordId"
            ],
            "properties": {
              "recordId": {
                "type": "string",
                "description": "The unique identifier of the original referenced record",
                "example": "REC67890"
              },
              "subTypeId": {
                "type": "string",
                "description": "Optional sub-type identifier for the original referenced record",
                "example": "agreement"
              },
              "namedTypeIds": {
                "type": "array",
                "description": "The unique identifiers of the relationship types associated with the original entity",
                "items": {
                  "type": "string",
                  "example": "43d3e321-e89b-12d3-a456-426614174000"
                }
              },
              "readableId": {
                "type": "string",
                "description": "The unique identifier of the original referenced record",
                "example": "ENTITY-2"
              },
              "attributes": {
                "$ref": "#/components/schemas/EntityProperties"
              }
            }
          }
        }
      },
      "RecordPropertyAddress": {
        "type": "object",
        "description": "An address-type record property",
        "required": [
          "type",
          "value"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The data type of the property",
            "enum": [
              "address"
            ],
            "example": "address"
          },
          "value": {
            "type": "object",
            "description": "The address",
            "example": {
              "lines": [
                "123 Main St."
              ],
              "locality": "Los Angeles",
              "region": "CA",
              "postcode": "90001"
            },
            "properties": {
              "lines": {
                "type": "array",
                "maxLength": 4,
                "items": {
                  "type": "string"
                },
                "description": "Address Lines (Street, Apt., etc.)"
              },
              "locality": {
                "type": "string",
                "description": "Locality (City, Town, etc)"
              },
              "country": {
                "type": "string",
                "description": "Country"
              },
              "region": {
                "type": "string",
                "description": "Region (State, Province, etc)"
              },
              "postcode": {
                "type": "string",
                "description": "Postcode (ZIP code, etc)"
              },
              "raw": {
                "type": "string",
                "description": "A raw address string, useful when address is not stored in a structured way"
              }
            }
          },
          "originalValue": {
            "type": "object",
            "description": "The original address before amendment (only present when property is amended)",
            "example": {
              "lines": [
                "456 Old St."
              ],
              "locality": "San Francisco",
              "region": "CA",
              "postcode": "94102"
            },
            "properties": {
              "lines": {
                "type": "array",
                "maxLength": 4,
                "items": {
                  "type": "string"
                },
                "description": "Original Address Lines (Street, Apt., etc.)"
              },
              "locality": {
                "type": "string",
                "description": "Original Locality (City, Town, etc)"
              },
              "country": {
                "type": "string",
                "description": "Original Country"
              },
              "region": {
                "type": "string",
                "description": "Original Region (State, Province, etc)"
              },
              "postcode": {
                "type": "string",
                "description": "Original Postcode (ZIP code, etc)"
              },
              "raw": {
                "type": "string",
                "description": "A raw original address string, useful when address is not stored in a structured way"
              }
            }
          }
        }
      },
      "RecordPropertyPlaybookClause": {
        "type": "object",
        "description": "A playbook-based clause-type record property",
        "required": [
          "type",
          "value"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The data type of the property",
            "enum": [
              "playbookClause"
            ],
            "example": "playbookClause"
          },
          "value": {
            "type": "string",
            "description": "The playbook clause name",
            "example": "Standard"
          }
        }
      },
      "RecordPropertyClause": {
        "type": "object",
        "description": "A clause-type record property",
        "required": [
          "type",
          "value"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The data type of the property",
            "enum": [
              "clause"
            ],
            "example": "clause"
          },
          "value": {
            "type": "object",
            "description": "The clause value of the property",
            "required": [
              "source"
            ],
            "properties": {
              "source": {
                "type": "string",
                "description": "The source of the clause property",
                "enum": [
                  "ai",
                  "manual"
                ],
                "example": "ai"
              },
              "clauseType": {
                "type": "string",
                "description": "The string key denoting which type of clause used",
                "example": "remedies"
              },
              "clauseText": {
                "type": "string",
                "description": "The actual paragraph text used",
                "example": "This agreement is governed by the laws of the State of California."
              },
              "documentId": {
                "type": "string",
                "description": "The unique identifier of the document that contains the clause",
                "example": "signedCopy"
              },
              "languagePosition": {
                "type": "object",
                "description": "The position of the clause in the document",
                "oneOf": [
                  {
                    "$ref": "#/components/schemas/ClauseLanguagePositionCustom"
                  },
                  {
                    "$ref": "#/components/schemas/ClauseLanguagePositionPlaybook"
                  }
                ]
              },
              "documentLocation": {
                "type": "object",
                "description": "The autoML style formatted location of the clause in the document",
                "required": [
                  "startOffset",
                  "endOffset",
                  "boundingPoly"
                ],
                "properties": {
                  "startOffset": {
                    "type": "integer",
                    "description": "The position in the document where the clause begins",
                    "example": 0
                  },
                  "endOffset": {
                    "type": "integer",
                    "description": "The position in the document where the clause ends",
                    "example": 0
                  },
                  "boundingPoly": {
                    "type": "array",
                    "description": "The bounding polygon of the clause in the document",
                    "items": {
                      "type": "object",
                      "required": [
                        "x",
                        "y"
                      ],
                      "properties": {
                        "x": {
                          "type": "integer",
                          "description": "The x coordinate of the bounding polygon",
                          "example": 0
                        },
                        "y": {
                          "type": "integer",
                          "description": "The y coordinate of the bounding polygon",
                          "example": 0
                        }
                      }
                    }
                  },
                  "pageNumber": {
                    "type": "integer",
                    "description": "The page number of the clause in the document",
                    "example": 1
                  }
                }
              }
            }
          }
        }
      },
      "ClauseLanguagePositionCustom": {
        "title": "Clause Language Position Custom",
        "type": "object",
        "description": "A custom clause language position",
        "required": [
          "type"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The source type of the custom clause",
            "enum": [
              "custom"
            ],
            "example": "custom"
          }
        }
      },
      "ClauseLanguagePositionPlaybook": {
        "title": "Clause Language Position Playbook",
        "type": "object",
        "description": "A playbook clause language position",
        "required": [
          "type",
          "name",
          "preferred"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The source type of the playbook clause",
            "enum": [
              "playbook"
            ],
            "example": "playbook"
          },
          "name": {
            "type": "string",
            "description": "The name of the playbook clause",
            "example": "Standard"
          },
          "preferred": {
            "type": "boolean",
            "description": "Whether the playbook clause is the preferred language",
            "example": true
          }
        }
      },
      "RecordPropertyMonetaryAmount": {
        "title": "Record Property Monetary Amount",
        "type": "object",
        "description": "A monetary amount-type record property",
        "required": [
          "type",
          "value"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The data type of the property",
            "enum": [
              "monetary_amount"
            ],
            "example": "monetary_amount"
          },
          "value": {
            "type": "object",
            "description": "The monetary amount value of the property",
            "required": [
              "amount",
              "currency"
            ],
            "properties": {
              "currency": {
                "type": "string",
                "description": "The currency of the monetary value in ISO 4217 format",
                "example": "USD"
              },
              "amount": {
                "type": "number",
                "description": "The amount of the monetary value",
                "example": 100000
              }
            }
          },
          "originalValue": {
            "type": "object",
            "description": "The original value of the property before amendment (only present when property is amended)",
            "required": [
              "amount",
              "currency"
            ],
            "properties": {
              "currency": {
                "type": "string",
                "description": "The currency of the original monetary value in ISO 4217 format",
                "example": "USD"
              },
              "amount": {
                "type": "number",
                "description": "The original amount of the monetary value",
                "example": 50000
              }
            }
          }
        }
      },
      "RecordPropertyEmail": {
        "title": "Record Property Email",
        "type": "object",
        "description": "An email-type record property",
        "required": [
          "type",
          "value"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The data type of the property",
            "enum": [
              "email"
            ],
            "example": "email"
          },
          "value": {
            "type": "string",
            "format": "email",
            "description": "The email value of the property",
            "example": "ironclad@example.com"
          },
          "originalValue": {
            "type": "string",
            "format": "email",
            "description": "The original value of the property before amendment (only present when property is amended)",
            "example": "original@example.com"
          }
        }
      },
      "RecordPropertyDuration": {
        "title": "Record Property Duration",
        "type": "object",
        "description": "A duration-type record property",
        "required": [
          "type",
          "value"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The data type of the property",
            "enum": [
              "duration"
            ],
            "example": "duration"
          },
          "value": {
            "type": "string",
            "description": "The duration value of the property in ISO8601 format",
            "example": "P10Y3M2W1D"
          },
          "originalValue": {
            "type": "string",
            "description": "The original value of the property before amendment (only present when property is amended)",
            "example": "P5Y1M1W"
          }
        }
      },
      "RecordPropertyDate": {
        "title": "Record Property Date",
        "type": "object",
        "description": "A date-type record property",
        "required": [
          "type",
          "value"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The data type of the property",
            "enum": [
              "date"
            ],
            "example": "date"
          },
          "value": {
            "type": "string",
            "description": "The date value of the property in ISO8601 format",
            "format": "date-time",
            "example": "1992-10-04T09:31:00Z"
          },
          "originalValue": {
            "type": "string",
            "description": "The original value of the property before amendment (only present when property is amended)",
            "format": "date-time",
            "example": "1990-01-01T00:00:00Z"
          }
        }
      },
      "RecordPropertyBoolean": {
        "title": "Record Property Boolean",
        "type": "object",
        "description": "A true/false boolean-type record property",
        "required": [
          "type",
          "value"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The data type of the property",
            "enum": [
              "boolean"
            ],
            "example": "boolean"
          },
          "value": {
            "type": "boolean",
            "description": "The boolean value of the property",
            "example": true
          },
          "originalValue": {
            "type": "boolean",
            "description": "The original value of the property before amendment (only present when property is amended)",
            "example": false
          }
        }
      },
      "RecordPropertyNumber": {
        "title": "Record Property Number",
        "type": "object",
        "description": "A number-type record property",
        "required": [
          "type",
          "value"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The data type of the property",
            "enum": [
              "number"
            ],
            "example": "number"
          },
          "value": {
            "type": "number",
            "description": "The number value of the property, which may be a decimal. Built-in record duration and turn-time properties (`workflowProcessAttributes_*Duration`, `workflowTurnTrackingTimeWith*`, `workflowAverageTurnTimeWith*`) are in milliseconds and can exceed 2,147,483,647, so store them as 64-bit integers or decimals.",
            "example": 123
          },
          "originalValue": {
            "type": "number",
            "description": "The original value of the property before amendment (only present when property is amended)",
            "example": 100
          }
        }
      },
      "RecordPropertyString": {
        "title": "Record Property String",
        "type": "object",
        "description": "A text-type record property",
        "required": [
          "type",
          "value"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The data type of the property",
            "enum": [
              "string"
            ],
            "example": "string"
          },
          "value": {
            "type": "string",
            "description": "The string value of the property",
            "example": "Foobar"
          },
          "originalValue": {
            "type": "string",
            "description": "The original value of the property before amendment (only present when property is amended)",
            "example": "Original Value"
          }
        }
      },
      "SourcedFromWorkflow": {
        "title": "Sourced From Workflow",
        "type": "object",
        "description": "Record created from an Ironclad workflow",
        "required": [
          "type",
          "workflowId"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The source type of the record",
            "enum": [
              "workflow"
            ],
            "example": "workflow"
          },
          "workflowId": {
            "type": "string",
            "description": "The unique identifier of the workflow that created the record",
            "example": "workflow:4a785686-d3d5-47bc-960e-3df0df871ea9"
          }
        }
      },
      "SourcedFromImportProject": {
        "title": "Sourced From Import Project",
        "type": "object",
        "description": "Record created from an import project",
        "required": [
          "type",
          "importId"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The source type of the record",
            "enum": [
              "import_project"
            ],
            "example": "import_project"
          },
          "importId": {
            "type": "string",
            "description": "The unique identifier of the import project that created the record",
            "example": "4a785686-d3d5-47bc-960e-3df0df871ea9"
          }
        }
      },
      "SourcedFromSingleImport": {
        "title": "Sourced From Single Import",
        "type": "object",
        "description": "Record created from a single import",
        "required": [
          "type"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The source type of the record",
            "enum": [
              "single_import"
            ],
            "example": "single_import"
          }
        }
      },
      "SourcedFromClickwrap": {
        "title": "Sourced From Clickwrap",
        "type": "object",
        "description": "Record created from a clickwrap agreement",
        "required": [
          "type",
          "clickwrapId"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The source type of the record",
            "enum": [
              "clickwrap"
            ],
            "example": "clickwrap"
          },
          "clickwrapId": {
            "type": "string",
            "description": "The unique identifier of the clickwrap agreement that created the record",
            "example": "4a785686-d3d5-47bc-960e-3df0df871ea9"
          }
        }
      },
      "SourcedFromConnector": {
        "title": "Sourced From Connector",
        "type": "object",
        "description": "Record created from a connector integration",
        "required": [
          "type",
          "connectorId"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The source type of the record",
            "enum": [
              "connector"
            ],
            "example": "connector"
          },
          "connectorId": {
            "type": "string",
            "description": "The unique identifier of the connector integration that created the record",
            "example": "4a785686-d3d5-47bc-960e-3df0df871ea9"
          }
        }
      },
      "SourcedFromIntegration": {
        "title": "Sourced From Integration",
        "type": "object",
        "description": "Record created from an integration",
        "required": [
          "type",
          "integrationName"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The source type of the record",
            "enum": [
              "integration"
            ],
            "example": "integration"
          },
          "integrationName": {
            "type": "string",
            "description": "The name of the integration that created the record",
            "example": "s4hana"
          }
        }
      },
      "SourcedFromContract": {
        "title": "Sourced From Contract",
        "type": "object",
        "description": "Record created from a contract (typically an obligation)",
        "required": [
          "type",
          "contractId"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The source type of the record",
            "enum": [
              "contract"
            ],
            "example": "contract"
          },
          "contractId": {
            "type": "string",
            "description": "The unique identifier of the contract that created the record",
            "example": "4a785686-d3d5-47bc-960e-3df0df871ea9"
          }
        }
      },
      "SourcedFromMetadataImport": {
        "title": "Sourced From Metadata Import",
        "type": "object",
        "description": "Record created from a metadata import",
        "required": [
          "type",
          "metadataImportId"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The source type of the record",
            "enum": [
              "metadata_import"
            ],
            "example": "metadata_import"
          },
          "metadataImportId": {
            "type": "string",
            "description": "The unique identifier of the metadata import that created the record",
            "example": "4a785686-d3d5-47bc-960e-3df0df871ea9"
          }
        }
      },
      "SourcedFromAiChat": {
        "title": "Sourced From AI Chat",
        "type": "object",
        "description": "Record created from an AI chat",
        "required": [
          "type",
          "chatId"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The source type of the record",
            "enum": [
              "ai_chat"
            ],
            "example": "ai_chat"
          },
          "chatId": {
            "type": "string",
            "description": "The unique identifier of the AI chat that created the record",
            "example": "4a785686-d3d5-47bc-960e-3df0df871ea9"
          }
        }
      },
      "SourcedFromAiExtraction": {
        "title": "Sourced From AI Extraction",
        "type": "object",
        "description": "Entity created by AI entity extraction from a contract",
        "required": [
          "type",
          "bulkRunId"
        ],
        "properties": {
          "type": {
            "type": "string",
            "description": "The source type of the record",
            "enum": [
              "ai_extraction"
            ],
            "example": "ai_extraction"
          },
          "bulkRunId": {
            "type": "string",
            "description": "The unique identifier of the bulk extraction run that created the record",
            "example": "89ef54fa-255a-4257-9832-a38b05a3bfff"
          }
        }
      },
      "LinkType": {
        "type": "string",
        "enum": [
          "amendment",
          "obligation"
        ],
        "description": "Identifies the type of relationship this child record has with its parent (e.g. amendment)"
      }
    },
    "parameters": {
      "QueryPageNumber": {
        "name": "page",
        "in": "query",
        "description": "The page number used when paginating through a list of results.",
        "schema": {
          "type": "integer",
          "format": "int32",
          "default": 0,
          "minimum": 0,
          "maximum": 100000000
        }
      },
      "QueryPageSize": {
        "name": "pageSize",
        "in": "query",
        "description": "A limit of the number of results to return.",
        "schema": {
          "type": "integer",
          "format": "int32",
          "minimum": 1,
          "maximum": 100,
          "default": 20
        }
      },
      "HydrateEntitiesFlag": {
        "name": "hydrateEntities",
        "in": "query",
        "description": "Indicates whether to fully hydrate related entities (true) or return minimal information (false).",
        "required": false,
        "schema": {
          "type": "boolean",
          "default": false
        }
      },
      "RecordFilter": {
        "name": "filter",
        "in": "query",
        "description": "Filter records using a formula. The record property ID should be enclosed in brackets `[ ]` and the value should be enclosed in single quotes `' '`. \n\nRecord properties can be identified using the [Retrieve Records Schema](https://developer.ironcladapp.com/reference/list-all-records-metadata) endpoint.\n\nSupported formula operations include the following with documentation found [here](/reference/filter-query-param):\n\n<ul>\n <li>Equals / NotEqual</li>\n <li>Contains</li>\n <li>IsEmpty / IsNotEmpty</li>\n <li>LessThan / LessThanOrEqual</li>\n <li>GreaterThan / GreaterThanOrEqual</li>\n <li>Date / Today / RelativeDate</li>\n <li>And / Or</li>\n</ul>",
        "schema": {
          "type": "string"
        },
        "example": "Equals([counterpartyName], 'Test LLC')"
      },
      "RecordSearch": {
        "name": "search",
        "in": "query",
        "description": "Free-text search across all record properties, matching the in-app search. Combined with `filter` and any other parameters using logical AND. Maximum 1000 characters.",
        "schema": {
          "type": "string",
          "maxLength": 1000
        },
        "example": "master services agreement"
      },
      "RecordType": {
        "name": "types",
        "in": "query",
        "description": "Comma separated (no spaces) record types to export. Use the [Retrieve Records Schema](https://developer.ironcladapp.com/reference/list-all-records-metadata) endpoint to retrieve a list of types.",
        "example": "mutualNDA,consultingAgreement",
        "schema": {
          "type": "string"
        }
      },
      "RecordLastUpdated": {
        "name": "lastUpdated",
        "in": "query",
        "description": "Get records updated since (UTC)",
        "example": "2018-03-10T00:00:00.000Z",
        "schema": {
          "type": "string"
        }
      },
      "XAsUserEmail": {
        "name": "x-as-user-email",
        "in": "header",
        "description": "Denotes the actor of the request. When used, the API will take into account this user's permissions and access. This or `x-as-user-id` is required when the associated token was produced from the Client Credentials grant or with legacy bearer tokens on select endpoints. A token produced from the Authorization Code grant (which is already scoped to a user) may also use this header to act as a different user in the same company, provided the token carries the `identity.users.impersonate` scope and the token's own user has been granted the API User Impersonation permission. A request that sends this header without both never acts as the named user; depending on the company's configuration it either proceeds as the token's own user or is rejected with a 403. More information about [permissions](https://support.ironcladapp.com/hc/en-us/articles/23063233934999-Ironclad-Permissions-Overview).",
        "required": false,
        "schema": {
          "type": "string",
          "example": "jane.doe@test.com"
        }
      },
      "XAsUserId": {
        "name": "x-as-user-id",
        "in": "header",
        "description": "Denotes the actor of the request. When used, the API will take into account this user's permissions and access. This or `x-as-user-email` is required when the associated token was produced from the Client Credentials grant or with legacy bearer tokens on select endpoints. A token produced from the Authorization Code grant (which is already scoped to a user) may also use this header to act as a different user in the same company, provided the token carries the `identity.users.impersonate` scope and the token's own user has been granted the API User Impersonation permission. A request that sends this header without both never acts as the named user; depending on the company's configuration it either proceeds as the token's own user or is rejected with a 403. More information about [permissions](https://support.ironcladapp.com/hc/en-us/articles/23063233934999-Ironclad-Permissions-Overview).",
        "required": false,
        "schema": {
          "type": "string",
          "example": "5f0375c4cdc1927a3c5edcd3"
        }
      },
      "addressAsObject": {
        "name": "addressAsObject",
        "in": "query",
        "description": "When true, returns addresses as objects instead of strings.",
        "schema": {
          "type": "boolean",
          "default": false
        }
      }
    },
    "securitySchemes": {
      "sec0": {
        "type": "apiKey",
        "in": "header",
        "name": "Authorization",
        "x-bearer-format": "bearer"
      },
      "OAuth2": {
        "type": "oauth2",
        "flows": {
          "authorizationCode": {
            "authorizationUrl": "https://ironcladapp.com/oauth/authorize",
            "tokenUrl": "https://ironcladapp.com/oauth/token",
            "scopes": {
              "public.records.createRecords": "Create Records",
              "public.records.readRecords": "Read Records",
              "public.records.updateRecords": "Update Records",
              "public.records.deleteRecords": "Delete Records",
              "public.records.readSchemas": "Read Record Schemas",
              "public.records.createAttachments": "Create Record Attachments",
              "public.records.readAttachments": "Read Record Attachments",
              "public.records.deleteAttachments": "Delete Record Attachments",
              "public.records.createSmartImportRecords": "Create Records via Smart Import",
              "public.records.readSmartImportRecords": "Read Record Import Details from Smart Import",
              "public.records.applyContractAction": "Apply Contract Actions",
              "public.webhooks.createWebhooks": "Create Webhooks",
              "public.webhooks.readWebhooks": "Read Webhooks",
              "public.webhooks.updateWebhooks": "Update Webhooks",
              "public.webhooks.deleteWebhooks": "Delete Webhooks",
              "public.workflows.createWorkflows": "Create Workflows",
              "public.workflows.readWorkflows": "Read Workflows",
              "public.workflows.updateWorkflows": "Update Workflows",
              "public.workflows.createFromSource": "Launch Workflow from Attribute Source",
              "public.workflows.updateFromSource": "Refresh Workflow from Attribute Source",
              "public.workflows.readApprovals": "Read Workflow Approvals",
              "public.workflows.updateApprovals": "Update Workflow Approvals",
              "public.workflows.readSignatures": "Read Workflow Signatures",
              "public.workflows.uploadSignedDocuments": "Upload Signed Workflow Documents",
              "public.workflows.readParticipants": "Read Workflow Participants",
              "public.workflows.readRoleAssignees": "Read Workflow Role Eligible Assignees",
              "public.workflows.updateRoleAssignment": "Update Workflow Role Assignment",
              "public.workflows.revertToReview": "Revert Workflows to Review",
              "public.workflows.cancel": "Cancel Workflows",
              "public.workflows.pauseAndResume": "Resume and Pause Workflows",
              "public.workflows.createComments": "Create Workflow Comments",
              "public.workflows.readComments": "Read Workflow Comments",
              "public.workflows.createDocuments": "Create Workflow Documents",
              "public.workflows.readDocuments": "Read Workflow Documents",
              "public.workflows.updateSignaturePacket": "Update Signature Packet",
              "public.workflows.readSchemas": "Read Workflow Schemas",
              "public.workflows.readTurnHistory": "Read Workflow Turn History",
              "public.workflows.readEmailCommunications": "Read Workflow Email Communications",
              "public.workflows.readSignStatus": "Read Sign Status",
              "public.records.createComments": "Create Workflow Comments",
              "public.export.createReports": "Create Reports",
              "public.export.readReports": "Read Reports",
              "public.workflows.createSignatureRecipientUrls": "Create Signature Request Recipient URLs",
              "public.workflows.createEmbeddableSignerUrls": "Create Embeddable Signature Request Recipient URLs",
              "public.workflows.sendSignatureRequests": "Send Signature Requests",
              "public.workflows.cancelSignatureRequests": "Cancel Signature Requests",
              "public.workflows.deleteSigners": "Delete Signers",
              "public.workflows.remindSigners": "Remind Signers",
              "public.workflows.updateSigners": "Update Signers",
              "public.entities.readRelationshipTypes": "Read Relationship Types",
              "public.entities.updateEntities": "Update Entities",
              "public.entities.deleteEntities": "Delete Entities",
              "public.entities.createEntities": "Create Entities",
              "public.entities.readEntities": "Read Entities",
              "public.obligations.readObligations": "Read Obligations",
              "public.obligations.createObligations": "Create Obligations",
              "public.obligations.updateObligations": "Update Obligations",
              "public.obligations.deleteObligations": "Delete Obligations",
              "public.workflows.scheduleSendSignatureRequest": "Schedule Send Signature Request",
              "public.workflows.updateScheduledSignatureRequest": "Update Scheduled Signature Request",
              "public.workflows.deleteScheduledSignatureRequest": "Delete Scheduled Signature Request",
              "public.signatureRequests.updateRequest": "Update Custom Signature Request Status",
              "public.search.conversational": "Run Conversational agent Search",
              "public.adapters.triggerFlow": "Trigger Adapter Flows"
            }
          },
          "clientCredentials": {
            "tokenUrl": "https://ironcladapp.com/oauth/token",
            "scopes": {
              "public.records.createRecords": "Create Records",
              "public.records.readRecords": "Read Records",
              "public.records.updateRecords": "Update Records",
              "public.records.deleteRecords": "Delete Records",
              "public.records.readSchemas": "Read Record Schemas",
              "public.records.createAttachments": "Create Record Attachments",
              "public.records.readAttachments": "Read Record Attachments",
              "public.records.deleteAttachments": "Delete Record Attachments",
              "public.records.createSmartImportRecords": "Create Records via Smart Import",
              "public.records.readSmartImportRecords": "Read Record Import Details from Smart Import",
              "public.records.applyContractAction": "Apply Contract Actions",
              "public.webhooks.createWebhooks": "Create Webhooks",
              "public.webhooks.readWebhooks": "Read Webhooks",
              "public.webhooks.updateWebhooks": "Update Webhooks",
              "public.webhooks.deleteWebhooks": "Delete Webhooks",
              "public.workflows.createWorkflows": "Create Workflows",
              "public.workflows.readWorkflows": "Read Workflows",
              "public.workflows.updateWorkflows": "Update Workflows",
              "public.workflows.createFromSource": "Launch Workflow from Attribute Source",
              "public.workflows.updateFromSource": "Refresh Workflow from Attribute Source",
              "public.workflows.readApprovals": "Read Workflow Approvals",
              "public.workflows.updateApprovals": "Update Workflow Approvals",
              "public.workflows.readSignatures": "Read Workflow Signatures",
              "public.workflows.uploadSignedDocuments": "Upload Signed Workflow Documents",
              "public.workflows.readParticipants": "Read Workflow Participants",
              "public.workflows.readRoleAssignees": "Read Workflow Role Eligible Assignees",
              "public.workflows.updateRoleAssignment": "Update Workflow Role Assignment",
              "public.workflows.revertToReview": "Revert Workflows to Review",
              "public.workflows.cancel": "Cancel Workflows",
              "public.workflows.pauseAndResume": "Resume and Pause Workflows",
              "public.workflows.createComments": "Create Workflow Comments",
              "public.workflows.readComments": "Read Workflow Comments",
              "public.workflows.createDocuments": "Create Workflow Documents",
              "public.workflows.readDocuments": "Read Workflow Documents",
              "public.workflows.updateSignaturePacket": "Update Signature Packet",
              "public.workflows.readSchemas": "Read Workflow Schemas",
              "public.workflows.readTurnHistory": "Read Workflow Turn History",
              "public.workflows.readEmailCommunications": "Read Workflow Email Communications",
              "public.records.createComments": "Create Workflow Comments",
              "public.export.createReports": "Create Reports",
              "public.export.readReports": "Read Reports",
              "public.workflows.createSignatureRecipientUrls": "Create Signature Request Recipient URLs",
              "public.workflows.createEmbeddableSignerUrls": "Create Embeddable Signature Request Recipient URLs",
              "public.workflows.sendSignatureRequests": "Send Signature Requests",
              "public.workflows.cancelSignatureRequests": "Cancel Signature Requests",
              "public.workflows.deleteSigners": "Delete Signers",
              "public.workflows.remindSigners": "Remind Signers",
              "public.workflows.updateSigners": "Update Signers",
              "public.entities.readRelationshipTypes": "Read Relationship Types",
              "public.entities.updateEntities": "Update Entities",
              "public.entities.deleteEntities": "Delete Entities",
              "public.entities.createEntities": "Create Entities",
              "public.entities.readEntities": "Read Entities",
              "public.obligations.readObligations": "Read Obligations",
              "public.obligations.createObligations": "Create Obligations",
              "public.obligations.updateObligations": "Update Obligations",
              "public.obligations.deleteObligations": "Delete Obligations",
              "public.workflows.scheduleSendSignatureRequest": "Schedule Send Signature Request",
              "public.workflows.updateScheduledSignatureRequest": "Update Scheduled Signature Request",
              "public.workflows.deleteScheduledSignatureRequest": "Delete Scheduled Signature Request",
              "public.signatureRequests.updateRequest": "Update Custom Signature Request Status",
              "public.adapters.triggerFlow": "Trigger Adapter Flows"
            }
          }
        }
      }
    }
  },
  "tags": [
    {
      "name": "Records",
      "description": "Documentation on Ironclad Records."
    }
  ],
  "x-readme": {
    "headers": [],
    "explorer-enabled": true,
    "proxy-enabled": true,
    "samples-languages": [
      "curl",
      "node",
      "ruby",
      "javascript",
      "python"
    ]
  }
}
```